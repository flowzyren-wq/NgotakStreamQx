export const NGOTAK_SYNC_SCHEMA_VERSION = 1;
export const NGOTAK_SYNC_DIRECTORY = '.ngotakstreamqx-sync';

export type SyncRecordKind = 'download' | 'history' | 'watchlist';

export interface SyncedDownload {
  id: string;
  mediaKey?: string;
  title: string;
  showName?: string;
  episodeName?: string;
  seasonTitle?: string;
  type: 'movie' | 'series';
  imdbId?: string;
  poster?: string;
  background?: string;
  synopsis?: string;
  provider?: string;
  infoUrl?: string;
  sourceLink?: string;
  relativePath: string;
  totalBytes: number;
  completedAt: number;
  updatedAt: number;
}

export interface SyncedHistoryEpisode {
  id?: string;
  title: string;
  link: string;
  sourceLink?: string;
  description?: string;
  image?: string;
}

export interface SyncedHistory {
  id: string;
  title: string;
  poster?: string;
  background?: string;
  provider?: string;
  link: string;
  duration?: number;
  progress?: number;
  isSeries?: boolean;
  lastPlayed?: number;
  currentTime?: number;
  playbackRate?: number;
  episodeTitle?: string;
  episode?: SyncedHistoryEpisode;
  type?: string;
  cachedInfoData?: unknown;
  updatedAt: number;
}

export interface SyncedWatchListItem {
  title: string;
  poster: string;
  link: string;
  provider: string;
  updatedAt: number;
}

export interface SyncTombstone {
  kind: SyncRecordKind;
  id: string;
  mediaKey?: string;
  deletedAt: number;
}

export interface NgotakSyncManifest {
  schemaVersion: number;
  deviceId: string;
  revision: number;
  generatedAt: number;
  downloads: Record<string, SyncedDownload>;
  history?: Record<string, SyncedHistory>;
  watchlist?: Record<string, SyncedWatchListItem>;
  tombstones: Record<string, SyncTombstone>;
}

export interface MergedSyncState {
  downloads: Record<string, SyncedDownload>;
  history: Record<string, SyncedHistory>;
  watchlist: Record<string, SyncedWatchListItem>;
  tombstones: Record<string, SyncTombstone>;
}

export const MAX_SYNC_HISTORY_ITEMS = 50;

export const getTombstoneKey = (kind: SyncRecordKind, id: string): string =>
  `${kind}:${id}`;

const normalizeKeyPart = (value?: string): string =>
  (value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

const getEpisodeKey = (item: SyncedDownload): string => {
  const episodeNumber =
    item.id.match(/_E(\d+)$/i)?.[1] ||
    item.episodeName?.match(/(?:episode|ep|e)[\s_.-]*(\d+)/i)?.[1];
  if (episodeNumber) {
    return `i${Math.max(Number(episodeNumber) - 1, 0)}`;
  }
  const directIndex = item.id.match(/_direct_(\d+)$/i)?.[1];
  return directIndex ? `i${Number(directIndex)}` : 'i0';
};

const getSeasonKey = (item: SyncedDownload): string => {
  const normalized = normalizeKeyPart(item.seasonTitle);
  const plainSeason = normalized.match(/^season-?(\d+)$/)?.[1];
  return plainSeason ? String(Number(plainSeason)) : normalized;
};

export const getDownloadMediaKey = (item: SyncedDownload): string => {
  const identity = item.imdbId
    ? normalizeKeyPart(item.imdbId)
    : normalizeKeyPart(item.showName || item.title);
  return `${item.type}:${identity}:${getSeasonKey(item)}:${getEpisodeKey(item)}`;
};

const isManifest = (value: unknown): value is NgotakSyncManifest => {
  if (!value || typeof value !== 'object') {
    return false;
  }
  const manifest = value as Partial<NgotakSyncManifest>;
  return (
    manifest.schemaVersion === NGOTAK_SYNC_SCHEMA_VERSION &&
    typeof manifest.deviceId === 'string' &&
    typeof manifest.revision === 'number' &&
    Boolean(manifest.downloads) &&
    Boolean(manifest.tombstones)
  );
};

export const parseSyncManifest = (content: string): NgotakSyncManifest | null => {
  const parse = (value: string): NgotakSyncManifest | null => {
    try {
      const parsed = JSON.parse(value) as unknown;
      return isManifest(parsed) ? parsed : null;
    } catch {
      return null;
    }
  };
  const complete = parse(content);
  if (complete) {
    return complete;
  }

  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = 0; index < content.length; index += 1) {
    const character = content[index];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (character === '\\') {
        escaped = true;
      } else if (character === '"') {
        inString = false;
      }
      continue;
    }
    if (character === '"') {
      inString = true;
    } else if (character === '{') {
      depth += 1;
    } else if (character === '}') {
      depth -= 1;
      if (depth === 0) {
        return parse(content.slice(0, index + 1));
      }
    }
  }
  return null;
};

export const mergeSyncManifests = (
  manifests: NgotakSyncManifest[],
): MergedSyncState => {
  const downloads: Record<string, SyncedDownload> = {};
  const history: Record<string, SyncedHistory> = {};
  const watchlist: Record<string, SyncedWatchListItem> = {};
  const tombstones: Record<string, SyncTombstone> = {};

  for (const manifest of manifests) {
    for (const item of Object.values(manifest.downloads)) {
      const mediaKey = getDownloadMediaKey(item);
      const normalizedItem = {...item, mediaKey};
      if (
        !downloads[mediaKey] ||
        normalizedItem.updatedAt > downloads[mediaKey].updatedAt
      ) {
        downloads[mediaKey] = normalizedItem;
      }
    }
    for (const [link, item] of Object.entries(manifest.watchlist || {})) {
      if (!watchlist[link] || item.updatedAt >= watchlist[link].updatedAt) {
        watchlist[link] = item;
      }
    }
    for (const [id, item] of Object.entries(manifest.history || {})) {
      const existing = history[id];
      if (!existing) {
        history[id] = item;
      } else if (item.updatedAt >= existing.updatedAt) {
        history[id] = {
          ...existing,
          ...item,
          title: item.title || existing.title,
          poster: item.poster ?? existing.poster,
          background: item.background ?? existing.background,
          provider: item.provider ?? existing.provider,
          link: item.link || existing.link,
          episodeTitle: item.episodeTitle ?? existing.episodeTitle,
          episode: item.episode ?? existing.episode,
          type: item.type ?? existing.type,
          isSeries: item.isSeries ?? existing.isSeries,
          progress: item.progress ?? existing.progress,
          duration: item.duration ?? existing.duration,
          currentTime: item.currentTime ?? existing.currentTime,
        };
      }
    }
    for (const [key, tombstone] of Object.entries(manifest.tombstones)) {
      if (!tombstones[key] || tombstone.deletedAt > tombstones[key].deletedAt) {
        tombstones[key] = tombstone;
      }
    }
  }

  for (const tombstone of Object.values(tombstones)) {
    if (tombstone.kind === 'download') {
      const itemKey = Object.keys(downloads).find(
        key =>
          downloads[key].id === tombstone.id ||
          key === tombstone.id ||
          key === tombstone.mediaKey,
      );
      const item = itemKey ? downloads[itemKey] : undefined;
      if (item && tombstone.deletedAt >= item.updatedAt) {
        delete downloads[itemKey!];
      }
    } else if (tombstone.kind === 'history') {
      const item = history[tombstone.id];
      if (item && tombstone.deletedAt >= item.updatedAt) {
        delete history[tombstone.id];
      }
    } else {
      const item = watchlist[tombstone.id];
      if (item && tombstone.deletedAt >= item.updatedAt) {
        delete watchlist[tombstone.id];
      }
    }
  }

  const limitedHistory = Object.fromEntries(
    Object.entries(history)
      .sort(([, a], [, b]) => b.updatedAt - a.updatedAt)
      .slice(0, MAX_SYNC_HISTORY_ITEMS),
  );

  return {downloads, history: limitedHistory, watchlist, tombstones};
};
